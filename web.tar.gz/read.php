<!DOCTYPE html>
<html>

<head>
	<meta charset='utf-8'>
	<script src="/srcs/js/jquery-3.7.0.js"></script>
	<style>
		@font-face {
			font-family: 'nuni';
			src: url('./srcs/fonts/NunitoSans-VariableFont_YTLC,opsz,wdth,wght.ttf') format('truetype');
		}
		.read_table {
			border: 1px solid #444444;
			margin-top: 30px;
			table-layout: fixed;
		}

		.read_title {
			height: 50px;
			font-size: 24px;
			letter-spacing: 1.8px;
			text-align: center;
			background-color: #3c3c3c;
			color: white;
			width: 1000px;
		}

		.read_id {
			text-align: center;
			background-color: #eeeeee;
			width: 30px;
			height: 37px;
			letter-spacing: 1px;
		}

		.read_id2 {
			background-color: white;
			width: 60px;
			height: 37px;
			padding-left: 10px;
		}

		.read_hit {
			background-color: #eeeeee;
			width: 30px;
			text-align: center;
			height: 37px;
			letter-spacing: 1px;
		}

		.read_hit2 {
			background-color: white;
			width: 60px;
			height: 37px;
			padding-left: 10px;
		}

		.read_content {
			padding: 20px;
			border-top: 1px solid #444444;
			height: 400px;
		}

		.more {
			display: block;
			width: 70px;
			height: 20px;
			background-size: cover;
			background-image:url('./srcs/images/attachment_color_small.png');
		}	

		.blind {
			position: absolute;
			overflow: hidden;
			clip: rect(0 0 0 0);
			margin: -1px;
			width: 1px;
			height: 1px;
		}

		.more:hover, .close:hover {
			cursor: pointer;
		}

		.close {
			display: block;
			width: 15px;
			height: 20px;
			background-size: cover;
			background-image:url('./srcs/images/attachment_mono_small.png');
		}

		.download_field {
			width: 30px;
			height: auto;
			word-break: break-all;
		}
		.download_field a.list {
			font-family: 'nuni';
			font-size: 14.5px;
			margin-bottom:-2.5px;
			visibility: hidden;
			word-break: break-all;
		}

		.read_btn {
			width: 700px;
			height: 200px;
			text-align: center;
			margin: auto;
			margin-top: 50px;
		}

		.read_btn1 {
			height: 50px;
			width: 100px;
			font-size: 20px;
			text-align: center;
			background-color: white;
			border: 2px solid black;
			border-radius: 10px;
			cursor: pointer;
		}

		.read_btn1:hover {
			color: #5d5d5d;
		}

		.read_comment_input {
			width: 700px;
			height: 500px;
			text-align: center;
			margin: auto;
		}

		.read_text3 {
			font-weight: bold;
			float: left;
			margin-left: 20px;
		}

		.read_com_id {
			width: 100px;
		}

		.read_comment {
			width: 500px;
		}
	</style>
</head>

<body>
	<?php
		include './db/dbconnect.php';
		include './srcs/php/en_de_crypt.php';

		$num = $_GET['num'];

		session_start();

		// board 테이블 정보
		$query = "select title, content, date, hit, id from board where number = $num";
		if ( isset($_SESSION['num']) ) { $query = "select title, content, date, hit, id from board where number = {$_SESSION['num']}"; $num = $_SESSION['num']; }

		$result = $connect->query($query);
		$rows = mysqli_fetch_assoc($result);
		$user = $rows['id'];
		$title = $rows['title'];
		$content = $rows['content'];
		$counting = $rows['hit'] + 1;
		$query = "update board set hit = '$counting' where number = $num";
		if ( isset($_SESSION['num']) ) { $query = "update board set hit = '$counting' where number = {$_SESSION['num']}"; }
		mysqli_query($connect, $query);
	
		// file 테이블 정보
		$query = "select name, location from file where board_num = $num";
		if ( isset($_SESSION['num']) ) { $query = "select name, location from file where board_num = {$_SESSION['num']}"; }
		$result = $connect->query($query);
		$file_total = mysqli_num_rows($result);

		$i = 0;
		while ( $rows = mysqli_fetch_assoc($result) ) {
		      $file_name[$i] = $rows['name'];
		      $file_loc[$i] = $rows['location'];
		      $i++;
		}
		unset($i);

		// 익명 사용자 확인
		$query = "select password, id from board_pw where board_num = $num";
		if ( isset($_SESSION['num']) ) { $query = "select password, id from board_pw where board_num = {$_SESSION['num']}"; }
		$result = $connect->query($query);
		$row = mysqli_fetch_assoc($result);
		$decrypted_pw = Decrypt($row['password'], $secret_key, $secret_iv);
		unset( $_SESSION['num'] );

		if (isset($_SESSION['userid'])) {
		?><b><?php echo $_SESSION['userid']; ?></b>님 반갑습니다.
		  <button onclick="location.href='./logout_action.php'" style="float:right; font-size:15.5px;">로그아웃</button><br/>
		<?php
		} else {
		?>
		  <button onclick="location.href='./login.php'" style="float:right; font-size:15.5px;">로그인</button><br/> 
		<?php
		}
		?>

	<table class="read_table" align=center>
		<tr>
			<th colspan="4" class="read_title"><?php echo $title ?></th>
		</tr>
		<tr>
			<td class="read_id">작성자</td>
			<td class="read_id2"><?php echo $user ?></td>
			<td class="read_hit">조회수</td>
			<td class="read_hit2"><?php echo $counting; ?></td>
		</tr>
		<tr>
			<td colspan="4" class="read_content" valign="top">
				<?php echo $content; ?>
			</td>
		</tr>
		<tr>
			<td colspan="4" class="download_field">
				<span class="more">
				</span>
				<?php $i = 0; 
				      while ( $i < $file_total) {
				?>
					<a href="<?=$file_loc[$i] ?>" download="<?=$file_name[$i] ?>" class="list"><?=$file_name[$i] ?></a>&nbsp;&nbsp;
				<?php 
					$i++; } unset($i);
				mysqli_close($connect);
				?>
			</td>
		</tr>
	</table>
	<div class="read_btn">
		<button class="read_btn1" onclick="location.href='./board.php'">목록</button>&nbsp;&nbsp;
	   <?php if (isset($_SESSION['userid']) and $_SESSION['userid'] == $user): ?>	
		<button class="read_btn1" onclick="location.href='./modify_member.php?num=<?= $num ?>'">수정</button>&nbsp;&nbsp;
		<button class="read_btn1" onclick="ask();">삭제</button>
	   <script>
		function ask() {
			if (confirm("게시글을 삭제하시겠습니까?")) {
				window.location = "./delete.php?num=<?=$num ?>";
			} else {
				alert("취소하셨습니다.");
			}
		};
	   </script>
	   <?php endif; ?>

	   <?php if ( $row['id'] ): ?>
		<button class="read_btn1" onclick="moAsk_db();">수정</button>&nbsp;&nbsp;
		<button class="read_btn1" onclick="deAsk_db();">삭제</button>
	   <?php endif; ?>


		<script>
			history.replaceState({}, null, location.pathname);
			$(document).ready(function(){
			 $('.more').click(function(){
			   if($('.more').hasClass('more')) {
			     $('.more').addClass('close').removeClass('more');
			     /* Removed list */
			     $('.list').css('visibility', 'visible');
			   } else if($('.close').hasClass('close')) {
			     $('.close').addClass('more').removeClass('close');
			     /* Added list */
			     $('.list').css('visibility', 'hidden');
			   }
			 })
			})


			function moAsk_db() {
				if (!confirm("게시글을 수정하시겠습니까?")) {
					alert("취소하셨습니다.");
				} else {
					var modifyPw = prompt("해당 게시글의 비밀번호를 입력해주세요.");
					var passWord = "<?php echo $row['password']; ?>";
					if ( modifyPw == passWord ) {
						alert("수정 화면으로 이동하겠습니다.");
						window.location = "./modify.php?num=<?=$num ?>";
					} else {
						alert("비밀번호가 맞지 않습니다.");
						location.replace("./read.php?num=<?=$num ?>");	
					}
				}
			};

			function deAsk_db() {
				if (!confirm("게시글을 삭제하시겠습니까?")) {
					alert("취소하셨습니다.");
				} else {
					var deletePw = prompt("해당 게시글의 비밀번호를 입력해주세요.");
					var passWord = "<?php echo $row['password']; ?>";
					if ( deletePw == passWord ) {
						alert("삭제하겠습니다.");
						window.location = "./delete.php?num=<?=$num ?>";
					} else {
						alert("비밀번호가 맞지 않습니다.");
						location.replace("./read.php?num=<?=$num ?>");	
					}
				}
			};


		</script>
	</div>
</body>

</html>

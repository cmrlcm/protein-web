<?php

include '../../db/dbconnect.php';
$id=$_POST["name"];  
$query = "select id from member where id = $id";

if ( $connect-> query($query) ) {
	$response = array(
		'status' => 'exist',	
		'message' => "존재하는 ID 입니다."
	);
} else {
	$response = array(
		'status' => 'Non_exist',
	);
}

header('Content-type: application/json');
echo json_encode($response);

mysqli_close($connect);

?>

function compare(x) {
	this.x = x;
	console.log(x);
	for(i=0; i<x.length; i++) {
		for(j=0; j<x.length; j++) {
			if ( i !== j && x[i] === x[j] ) {
				  return true;
			}
		}
	}
}


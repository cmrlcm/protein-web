<!DOCTYPE html>
<html>

<head>
    <meta charset='utf-8'>
</head>

<body>
    <div align="center">
        <span>
            <p style="font-size: 25px;"><b>회원가입</b></p>
        </span>

        <form method='post' action='register_action.php'>
            <p><b>I &nbsp;D &nbsp;</b><input name="id" type="text"></p>
            <p><b>PW &nbsp;</b><input name="pw" type="password"></p>
            <br />
            <input type="submit" value="가입하기">
        </form>
    </div>
</body>

</html>
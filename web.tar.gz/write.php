<!DOCTYPE html>
<html>
	<head>
		<meta charset='utf-8'>
		<script src="/srcs/js/jquery-3.7.0.js"></script>
		<style>
			table.table2 {
				border-collapse: separate;
				border-spacing: 1px;
				text-align: left;
				line-height: 1.5;
				border-top: 1px solid #ccc;	
				margin: 20px 10px;
			}

			table.table2 tr {
				width: 50px;
				padding: 10px;
				font-weight: bold; vertical-align: top;
			}
		
			table.table2 td {
				width: 100px;
				padding: 10px;
				vertical-align: top;
				border-bottom: 1px solid #ccc;
			}

			.read_btn {
                        	width: 100px;
	                        height: 55px;
       	                 	text-align: center;
                        	margin: auto;
                        	margin-top: 20px;
			}

			.read_btn1 {
				height: 40px;
				width: 50px;
				font-size: 20px;
				text-align: center;
				background-color: white;
				border: 2px solid black;
				border-radius: 10px;
				cursor: pointer;
			}

	                .read_btn1:hover {
				color: #5d5d5d;
			}

			div.finput {
				height: 49px;
				display: flex;
				align-items: center;
				justify-content: center;
				margin:-3px;
				
			}

			#file_input {
				display: none;
			}

			.file_list {
				width: 400px;
				height: 300px;
				text-align: center;
				margin: auto;
				font-size: 15px;
			}

			.file_remove {
				width: 22px;
				height: 22px;
				font-size: 12px;
				font-weight: bold;
				font-family: monospace;
				text-align: center;
				background-color: #dcdcdc;
				border-radius: 8px;
				border: 2px solid black;
				margin: auto;
				cursor: pointer;
			}
			
			p.margin {
				margin-top: 5px;
				margin-bottom: 2px;
			}
			#title_btn {
				font-size:25px; text-align:center; color:white; margin-top:15px; margin-bottom:15px;
				background-color: #3c3c3c; font-weight: bold; font-family: "arial, courier new, times new roman, default";
				border-top: none; border-left: none; border-right: none; border-bottom: none;
				cursor: pointer;
			}

			#title {
				outline-color: #3c3c3c;
				outline-style: solid;
				outline-width: 1px;
			}

			#title:link {
				background-color: #3c3c3c;
			}

			#title:hover {
				outline-color: #3c3c3c;
				outline-style: solid;
				outline-width: 3px;
			}
			
			input[type="text"]:focus {
				background-color: #b5cedf;
			}

			input[type="password"]:focus {
				background-color: #b5cedf;
			}
		</style>
		<script>

		</script>
	</head>

	<body>
		<form id="writeBoard" name="writeBoard" method="post" action="./write_action.php" enctype="multipart/form-data">
			<table style="padding-top:50px" align=center width=auto border=0 cellpadding=2>
				<tr>
					<th id="title" style="background-color: #3c3c3c"> 
						<input type='submit' id='title_btn' enctype="multipart/form-data" value="게시글 작성하기" > 
					</th>
				</tr>
				<tr>
					<td bgcolor=white>
						<table class="table2">
							<tr>
								<td>작성자</td>
								<td><input type="text" name="name" size=30 autofocus required></td>
							</tr>
							<tr>
								<td>제목</td>
								<td><input type="text" name="title" size=70 required></td>
							</tr>
							<tr>
								<td>내용</td>
								<td><textarea name="content" cols=75  rows=15></textarea></td>
							</tr>
							<tr>
								<td>비밀번호</td>
								<td><input type="password" name="pw" size=15 maxlength=15 required></td>
							</tr>
						</table>
					</td>
				</tr>
			</table>

		<input type="file" name="uploadFile[]" id="file_input" multiple>	<!-- 이것은 파일을 한 번에 여러개 선택 가능하게 해준다. -->
		<table class="read_btn">
		<tr>
			<td class="read_btn1" style="padding: 0px">
			<label for="file_input" style="cursor:pointer">
			<div class="finput">첨부</div>
			</label>
			</td>
		</tr>
		</table>
		<div class="file_list" id="preview">
		</div>
	<script>
		const filesArr = new Array();
		   const fileUploadCheck = {	
		     checkToDelete() {
		     	const uploadCheck = document.querySelector('#file_input');
		     	uploadCheck.addEventListener('change', function () {
				var fileName = Array();
				var fileLength = Array();
				var fileDot = Array();
				var fileNameType = Array();	
			  for (var j=0; j < uploadCheck.files.length; j++) {
				fileName.push(uploadCheck.files[j].name);
				fileLength.push(fileName[j].length);	// 파일명 길이
				fileDot.push(fileName[j].lastIndexOf("."));	// 파일명의 확장자 추출
				fileNameType[j] = fileName[j].substring(fileDot[j]+1, fileLength[j]).toLowerCase();	// 확장자 소문자로
			  }
			
			var safeType = Array("hwp", "doc", "docx", "ppt", "pptx", "xls", "xlsx", "txt", "csv", "jpg", "jpeg", "gif", "png", "bmp", "pdf", "tar", "gz", "xz", "bz2");
		   	  for (var i=0; i < uploadCheck.files.length; i++) {
			    if (safeType.some( (type) => type === fileNameType[i]) ) {
	   			handler.init(uploadCheck.files[i]);
			       let reader = new FileReader();
				filesArr.push(uploadCheck.files[i]);
				reader.readAsDataURL(uploadCheck.files[i]);
			    } else {
				alert("해당 확장자(." + fileNameType[i] + ")는 업로드가 불가능합니다.");
			    }
			  }
			const dataTransFer = new DataTransfer();
			   filesArr.forEach(file => {
			      dataTransFer.items.add(file);	
			   })

			document.querySelector('#file_input').files = dataTransFer.files;		
			console.dir(document.querySelector('#file_input').files);
 		     })
		     }
		   }


	   const handler = {
		init(file) {
		  const fileInput = file;
		  const preview = document.querySelector('#preview');
		      if (fileInput.name) {
		       preview.innerHTML += `
		       <p id="${fileInput.lastModified}" class="margin" >
		 	 ${fileInput.name}
			 <button data-index='${fileInput.lastModified}' id='remove_file' class='file_remove'>X</button>
		       </p>`;
		      }
		},

		removeFile: () => {
		  var r = document.getElementById('preview');
		  r.addEventListener('click', function (e) {

			  if(e.target.className != 'file_remove') return;
			  const removeTargetId = e.target.dataset.index;
			  const removeTarget = document.getElementById(removeTargetId);
			  console.dir("Id : " + removeTargetId);
			  const files = document.querySelector('#file_input').files;
			  const dataTranster = new DataTransfer();

// document.querySelector('#file_input').files =
// Array.from(files).filter(file => file.lastModified !== removeTarget);

		  let index = filesArr.findIndex(k => k.lastModified == removeTargetId);
		  filesArr.splice(index, 1);
			  Array.from(files)
			      .filter(file => file.lastModified != removeTargetId)
			      .forEach(file => {
			      dataTranster.items.add(file);
			      })
			  removeTarget.remove(); // Element의 remove()메소드 사용하려고
			  document.querySelector('#file_input').files = dataTranster.files;

	//document.getElement를 사용하려면 해당하는 문서요소(div, table, p 등)가 있어야 한다. 정확히는 HTML의 요소이다.
	
		  })
		}	
	   }

	   function notice() {
		if (confirm("동일한 이름의 파일이 존재합니다. 계속 진행하시겠습니까?")) {
			return true;
		} else {
			alert("취소하셨습니다.");
			let frm = document.writeBoard;
			frm.action ='<?=$_SERVER['PHP_SELF']?>';
			frm.submit();
		}
  	   }

	   fileUploadCheck.checkToDelete();
	   handler.removeFile();
	   
	</script>
	</form>
	</body>
</html>

/* 그려질 ball의 기본 속성을 정하는 부분: Ball.constructor(x,y)	*/
/* ball이 움직일 때마다 x,y값을 변경해주고, 테두리에 부딪히면 -1을 곱해서 반대로 움직이게 하는 부분: Ball.update() */
/* 생성된 ball들을 canvas에 그려주는 부분: Ball.draw() */
/* 위의 함수들을 약 1초에 60번씩 호출해서 반복시키는 부분: animate() */
// 이 아래 내용이 기본구조. 나는 중력값을 주자.

window.onload = function () {

	const canvas = document.getElementById('canvas');
	const ctx = canvas.getContext('2d');
	canvas.width = window.innerWidth;
	canvas.height = window.innerHeight;

	class Ball {
		constructor(x,y) { // 볼의 기본 속성들을 정의
		   this.x = x;
		   this.y = y;
		   this.c = 'rgba(0, 0, 0, 0.8)'; // 공 색깔 검은색. 80% 불투명도 
//'rgba('+Math.random()*255+','+Math.random()*255+','+Math.random()*255+')'
// 위의 코드는 공의 색깔을 랜덤하게 설정.

		   this.size = 15; // 공의 반지름

		   this.angle =	1.5*(Math.PI/2);	// 공이 출발할 각도, 나는 90도에서 조금 좌측으로 떨어지게 설정
// 작성자는 (Math.random()*(Math.PI*2))로 시작함. 파이*2 라디안은 360도를 뜻함.

		   this.power = 10; // 공의 세기
		   this.directionX = this.power*Math.cos(this.angle);		// 공이 좌우로 움직이는 값
		   
		   this.gravity = this.power*Math.sin(this.angle);		// 공이 상하로 움직이는 값
		}

		update(){	// 프레임마다 속성들을 변화시키는 함수
		   this.y += this.gravity; // y값을 계속 증가/감소시킨다.
		   if ( -0.0001111 <this.directionX && this.directionX < 0.0009999 ) {
			this.directionX = 0;
			this.gravity = 0;
			if (this.directionX == 0) {
				makeWindow(this.x, this.y);
				return;
			}
		   } else {
		   	this.gravity += 0.2; // 중력 값
		   } 

		   if (this.y + this.size > canvas.height || this.y - this.size < 0) {		// 상하 바운드 처리
			this.gravity *= -0.8;
			this.directionX *= 0.8;
		   }

		   this.x += this.directionX; // x값을 계속 증가/감소 시킨다.
		   this.directionX *= 1;
		   if (this.x + this.size > canvas.width || this.x - this.size < 0) {		// 좌우 바운드 처리
			this.directionX *= -0.9; // 좌우에 닿으면 방향을 전환
		   }
		}

		draw(){	// 넘어온 속성값대로 캔버스에 원을 그려주는 함수
		   ctx.fillStyle = this.c; 
		   ctx.beginPath();
		   ctx.arc(this.x, this.y, this.size, 0, Math.PI*2, true);
		   ctx.closePath();
		   ctx.fill();
		}
	}

	init = () => { // 그려질 공의 개체를 설정하는 함수
 		ball1 = new Ball(canvas.width*0.65, 12.0);
		console.log(ball1);
	}

	function animate() { // 매 프레임마다 그림을 새로 그려주는 함수

		ctx.fillStyle='rgba(255,255,255,0.7)';

// 매 프레임마다 캔버스를 통째로 칠하는 색깔. 
// 맨 마지막의 alpha값에 따라 공의 잔상이 남는 정도가 달라진다.

		ctx.fillRect(0,0,canvas.width,canvas.height); // 캔버스 전체를 색칠해서 내용을 지워준다.

		ball1.update(); // ball1의 좌표 등을 업데이트 한다.
		ball1.draw(); // 업데이트된 내용으로 ball을 새로 그린다.
		window.addEventListener('resize', function() { // 화면 크기가 변하면 캔버스 크기도 변경해줌
		   canvas.width = window.innerWidth;
		   canvas.height = window.innerHeight;
		})
		let cancel = requestAnimationFrame(animate);
	}

	makeWindow = (x, y) => {
		let m1 = document.getElementById('canvas').style;	
		m1.transition = "1s";
		ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
		ctx.fillRect(x, y, -700, -700); 
		ctx.clearRect(x-50, y-50, -600, -600); 
	}

	init(); // 공의 초기 좌표를 설정하고,
	animate(); // 프레임마다 공을 그려준다.
}

<?php
	// DB 연결

	include './db/dbconnect.php';
	if ($connect->mysql_error) {
	echo "connect_failed";
	}
	$query = "select * from board order by number desc"; // 역순 출력
	$result_mysql = mysqli_query($connect, $query);
	// $result = $connect->query($query);
	$total = mysqli_num_rows($result_mysql); //result set의 총 레코드(행) 수 반환
	
	// Session
	session_start();

	if (isset($_SESSION['userid'])) {
	?><b><?php echo $_SESSION['userid']; ?></b>님 반갑습니다.
	  <button onclick="location.href='./logout_action.php'" style="float:right; font-size:15.5px;">로그아웃</button><br/>
	<?php
	} else {
	?>
	  <button onclick="location.href='./login.php'" style="float:right; font-size:15.5px;">로그인</button><br/>
	<?php
	}
	

?>
<!DOCTYPE html>
<html lang='ko'>

<head>
	<mete charset='UTF-8'>
	<title>Board</title>
	<style>
		table { border-collapse: collapse; border-top: 3px solid #444444; position: static }
		.title { font-size:30px; letter-spacing: 15px; line-height: 3; }
		th { 
			border-bottom: 1px solid #efefef; letter-spacing: 2px; padding: 10px;
			background-color: white;
	 	}
		td { 
			border-bottom: 1px solid #efefef; letter-spacing: 1px; padding: 10px;
			cursor: pointer
		 }

		.myTableBody { border-bottom: 3px solid #444444; }
		.myTableBody tr:hover { background-color: #e1e1e1; } 
		tr:nth-child(odd) { background-color: #efefef; }
		span.relative {
			position: relative;
			margin: -28px;
			left : 365px;
			top : 20px;
			font-size: 15px; letter-spacing: 3px; 
		}
		.write:hover {
			text-decoration: underline;
		}

		#buttonPlace {
			border-bottom: 1px solid white;
		}

		.buttons {
			position: relative;
			padding: 1rem 0;
			display: inline-flex;
			justify-content: center;
		}

		.button {
			padding: 0 1rem;
			font-size: 1.3rem;
			color: #333;
			background: transparent;
			border: 0;
			outline: 0;
			cursor: pointer;
		}

		.button.active,
		.button:hover {
			color: #1f975d;
			font-weight: 600;
			text-decoration: underline;
		}

		.prev {
			position: absolute;
			left: -2.5rem;
			height: 1.449em;
		}

		.next {
			position: absolute;
			right: -2.5rem;
			height: 1.449em;
		}

		.prevImg {
			content:url(./srcs/images/chevron-back-outline.png);
			width: 1.4rem;
			height: 1.6rem;
			display: block;
		}

		.nextImg {
			content:url("./srcs/images/chevron-forward-outline.png");
			width: 1.4rem;
			height: 1.6rem;
			display: block;
		}
	</style>
</head>

<body>
<table align="center"> 
	<caption class="title" style="text-align:center;">
		<b>게시판</b>
		   <?php if (!isset($_SESSION['userid'])) {   ?>
			<span class="relative write" style = "cursor: pointer;" onClick="location.href='./write.php'">
				글쓰기
			</span>
		   <?php }
		         if (isset($_SESSION['userid'])) {    ?>
			<span class="relative write" style = "cursor: pointer;" onClick="location.href='./write_member.php'">
				글쓰기
			</span>
		   <?php } ?>
	</caption>
	<thead align="center"; clear:both>
	<tr> 
		<th width="50" align="center">번호</th>
		<th width="500" align="center">제목</th>
		<th width="100" align="center">작성자</th>
		<th width="200" align="center">날짜</th>
		<th width="80" align="center">조회수</th>
	</tr>
	</thead>

	<tbody class="myTableBody">
	<?php
	while ($rows = mysqli_fetch_assoc($result_mysql)) { //result_mysql set에서 레코드(행)를 1개씩 리턴
	?>
	<tr>
		<td width="50" align="center"><?php echo $total ?></td>
		<td width="500" align="center"><?php echo $rows['title'] ?></td>
		<td width="100" align="center"><?php echo $rows['id'] ?></td>
		<td width="200" align="center"><?php echo $rows['date'] ?></td>
		<td width="80" align="center"><?php echo $rows['hit'] ?></td>
		<td>
		<input type="hidden" value="<?=$rows['number']; ?>">
		</td>
	</tr>
	<?php
		$total--;
	}
	mysql_close($connect);
	?>
	</tbody>
	<tr>
		<td id="buttonPlace" bgcolor="white" colspan="5" align="center">
		<div class="buttons">
		</div>
		</td>
	</tr>
	  <script>
		const contents = document.querySelector(".myTableBody");
		const buttons = document.querySelector(".buttons");
		const prev = document.createElement("button");
		const next = document.createElement("button");
		const input = document.getElementsByTagName("input");
		const value = Array();
		for (let i=1; i <= input.length; i++) {
			value[i] = input[i-1].value;
		}

		const StringNumOfContent = contents.childElementCount;
		const numOfContent = parseInt(StringNumOfContent);
		const maxContent = 10;
		const maxButton = 5;
		const maxPage = Math.ceil(numOfContent / maxContent);
		const container = Array();
		const noEscape = Array();
		let page = 1;

		for (let i=1; i <= numOfContent; i++) {
			container[i] = contents.children[i-1].innerHTML;
			noEscape[i] = container[i].replace(/\n/g, "");
			noEscape[i] = noEscape[i].replace(/\t/g, "");
		}

		const makeContent = (id) => {
			const content = document.createElement("tr");
			content.classList.add("content");
			content.innerHTML = noEscape[id];
			content.addEventListener("click", (e) => {
			   	location.href=`./read.php?num=${value[id]}`;
			});
			return content;
		};

		const makeButton = (id) => {
			const button = document.createElement("button");
			button.classList.add("button");
			button.dataset.num = id;
			button.innerText = id;
			button.addEventListener("click", (e) => {
				Array.prototype.forEach.call(buttons.children, (button) => {
				    if (button.dataset.num) button.classList.remove("active");
				});
				e.target.classList.add("active");
				renderContent(parseInt(e.target.dataset.num));
			});
			return button;
		};

		const renderContent = (page) => {
			// 목록 리스트 초기화
			while (contents.hasChildNodes()) {
				contents.removeChild(contents.lastChild);
			};
			// 글의 최대 개수를 넘지 않는 선에서, 화면에 최대 10개의 글 생성
			for (let id = (page - 1) * maxContent + 1; id <= page * maxContent && id <= numOfContent; id++) {
				contents.appendChild(makeContent(id));
			}
		};

		const renderButton = (page) => {
			// 버튼 리스트 초기화
			while (buttons.hasChildNodes()) {
				buttons.removeChild(buttons.lastChild);
			}
			// 화면에 최대 5개의 페이지 버튼 생성
			for (let id = page; id < page + maxButton && id <= maxPage; id++) {
				buttons.appendChild(makeButton(id));
			}
			// 첫 버튼 활성화(class="active")
			buttons.children[0].classList.add("active");

			buttons.prepend(prev);
			buttons.append(next);

			// 이전, 다음 페이지 버튼이 필요한지 체크
			if (page - maxButton < 1) buttons.removeChild(prev);
			if (page + maxButton > maxPage) buttons.removeChild(next);
		};

		const render = (page) => {
			renderContent(page);
			renderButton(page);
		};
		render(page);

		const goPrevPage = () => {
			page -= maxButton;
			render(page);
		};

		const goNextPage = () => {
			page += maxButton;
			render(page);
		};

		prev.classList.add("button", "prev");
		prev.innerHTML = `<img class="prevImg">`;
		prev.addEventListener("click", goPrevPage);

		next.classList.add("button", "next");
		next.innerHTML = `<img class="nextImg">`;
		next.addEventListener("click", goNextPage);

	  </script>
	</tfoot>
</table>

</body>
</html>

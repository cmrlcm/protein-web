<?php
include './db/dbconnect.php';
include './srcs/php/change_name.php';
include './srcs/php/en_de_crypt.php';

	$id=$_POST["name"];			// Writer
	$pw=$_POST["pw"];			// Password
	$title=addslashes($_POST["title"]);	// Title 
	$content=addslashes($_POST["content"]);	// Content
	$content = str_replace("<", "&lt;", $content);
	$content = str_replace(">", "&gt;", $content);
	$content = str_replace("\n","<br/>", $content);
	$content = str_replace(" ","&nbsp", $content);
	$date=date('Y-m-d H:i:s');		// Date

	$URL = './board.php';			// return URL

	$upload = $_FILES["uploadFile"];
	$file_name = $upload['name'];

	$query = "insert into board (number, title, content, date, hit, id) values (null, '$title', '$content', '$date', 0, '$id')";
	$result = mysqli_query($connect, $query);
	if ($pw) {
	   $query = "insert into board_pw (board_num, id, password) values ((select number from board where date='$date' and id='$id'), '$id', '$pw')";
	   $result = mysqli_query($connect, $query);
	}

	$i = 0;
	while (true) {
		$i++;
		$isDir = is_dir("./uploads/$i/");
		if (!$isDir) {
			$target_dir = "./uploads/$i/";
			if ( $file_name[0] ) {
			   mkdir("./uploads/$i/", 0700, true);
			   for ($j=0; $j < count($file_name); $j++) {
				$error = $upload['error'][$j];
				$name = change_name($target_dir, $file_name[$j]);
				$target_file = $target_dir.basename($name);
				$target_tmp = $upload['tmp_name'][$j];
				move_uploaded_file( $target_tmp, $target_file );

				if ( !$error ) {
				$query = "insert into file (file_num, board_num, name, location, user_id, date) values (null, (select number from board where date='$date'), '$name', '$target_dir', '$id', '$date');";
				mysqli_query($connect, $query);
				}

				if ($error > 0 ) {
					?> <script> alert("<?php echo $error + "파일 업로드가 실패하였습니다." ?>"); </script>
				<?php
				}
			   }
			   unset ($j);
			}
			break;
		}
	}
	unset ($i);

if ($result) {
?>
<script>
	alert("<?php echo "게시글이 등록되었습니다." ?>");
	location.replace("<?php echo $URL ?>");
</script>
<?php
} else {
	echo "게시글 등록에 실패하였습니다.";
}

mysqli_close($connect);
?>

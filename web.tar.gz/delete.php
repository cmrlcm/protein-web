<?php
include './db/dbconnect.php';

$num = $_GET['num'];
session_start();

// 세션 값과 함께 보안강화용. 지금은 안씀.
$query = "select id from board where number = $num";
$result = $connect->query($query);
$rows = mysqli_fetch_assoc($result);

$userid = $rows['id'];

$URL = "./board.php";

$query = "delete from board where number = $num;";
$query .= "delete from board_pw where board_num = $num;";
$query .= "delete from file where board_num = $num;";
mysqli_multi_query($connect, $query);

mysqli_query($connect, $query);

/*	디렉터리, 업로드파일 삭제	*/
$delete_path = "./uploads/$num/";
if (is_dir($delete_path)) {
	rmdir_all($delete_path);
}

function rmdir_all($delete_path) {
	$dirs = dir($delete_path);

	while(false !== ($entry = $dirs->read())) {
		// 디렉토리의 내용을 하나씩 읽는다.
		if(($entry != '.') && ($entry != '..')) {
			// 디렉토리의 내용중 현재폴더, 상위폴더가 아니면 (즉 파일 및 디렉토리)            
			if(is_dir($delete_path.$entry)) {
				//디렉토리이면 재귀호출로 다시 삭제 시작.
				rmdir_all($delete_path.$entry);
			} else {
				//해당 파일 삭제
				@unlink($delete_path.$entry);
			}
		}
	}

	$dirs->close();

	// 최종 디렉토리 삭제
	@rmdir($delete_path);
}

?>
<script>
	history.replaceState({}, null, location.pathname);
	alert("<?php echo "게시글이 삭제되었습니다." ?>");
	location.replace("<?php echo $URL ?>");
</script>


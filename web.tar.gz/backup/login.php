<?php
	$id=$_POST["id"];
	$pw=$_POST["pw"];
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>로그인</title>
	</head>
	<body>
		<?=$id	?>님 환영합니다.
	</body>
</html>

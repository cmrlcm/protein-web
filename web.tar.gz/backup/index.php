<!DOCTYPE html>
<head>
	<style>
		header {
			border: 1px solid black;
			height:300px;
		}
		
		nav {
			border: 1px solid black;
			height:35px;
		}

		.main2 {
			border: 1px solid black;
			height: 1000px;
		}
		
		.main2 iframe {

		}

		.circle {

		}

	</style>
</head>

<body>
	<header>
	</header>
	<nav>
		<p><a href="board.php" target="login.php"></a></p>
	</nav>
	<main>
		<iframe src="login.php" name="login">
		</iframe>
	</main>
</body>
</html>

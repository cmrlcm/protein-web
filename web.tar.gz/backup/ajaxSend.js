function ajaxSend() {
        var formData = new FormData();

                formData.append("name", $(":text").val());
                formData.append("title", $(":text").val());
                formData.append("content", $("textarea").val());
                formData.append("pw", $(":password").val());

                const uploadFile = document.querySelector('#file_input');
                const dataTransfer = new DataTransfer();


                filesArr.forEach(file => {dataTransfer.items.add(file); });
                uploadFile.files = dataTransfer.files;

                $('uploadfile.files').each(function(index, file) {
                        formData.append("uploadFile[]", file);
                })
                console.dir(uploadFile);

                $.ajax({
                        url: './write_action.php',
                        type: "POST",
                        processData: false,     // 파일 전송시 필수
                        contentType: false,     // 파일 전송시 필수
                        data: formData
                })
                .done(function(data) {
                        console.log(data);
                })
}
$("button[id='title_btn']").click (function(e) {
        e.preventDefault();
        ajaxSend();
});


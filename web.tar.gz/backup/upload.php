<!DOCTYPE html>
<html>
<head>
</head>
<body>
<?php
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$file = $_FILES['file']['name'];
		$file_tmp = $_FILES['file']['file_tmp'];
		$file_cnt = count($file);
	}
?>
<script src="./js/jquery-3.7.0.js">
	$(document).ready(function () {
		var val = location.href.substr(
			location.href.lastIndexOf('=') + 1
		);
		upload.innerHTML += `
		 <p>${val.name}</p>`;
	};	

	function numgyu() {
		var formData = new FormData(document.getElementById("test"));
		formData.append("attachedImage", fileMul.cnt());
		$.ajax({
			url: ./upload_action.php,
			type: 'post',
			data: formData,
			cache: false,
			contentType: false,
			processData: false,
			error: function(jqXHR, textstatus, errorThrown) {
			},
			success: function(data, jqXHR, textStatus) {
			}
		});
	}
</script>

	<form method="post" id="test" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" enctype="multipart/form-data">
		<input type='file' id='file_upload' name='file[]' multiple='multiple'>
		<div id='preview'></div>
		<p id='upload' style='border:1px solid black;'>jhi</p>
	</form>
		<button id='test' onclick='numgyu()'>return</button>

	<script>
	   console.log("hi");
	   console.dir('#file_upload');
           const handler = {
                init() {
                  const fileInput = document.querySelector('#file_upload');
                  const preview = document.querySelector('#preview');
                  fileInput.addEventListener('change', () => {
                    console.dir(fileInput)
                    const files = Array.from(fileInput.files)
                    files.forEach(file => {
                      preview.innerHTML += `
                      <p id="${file.lastModified}" class="margin" >
                        ${file.name}
                        <button data-index='${file.lastModified}' id='remove_file' class='file_remove'>X</button>
                      </p>`;
                    })
                  })
                }
	}
handler.init();
	const fileMul = {
	   cnt() {
		var file = document.querySelector('#file_upload');
		file.addEventListener('change', () => {
			console.log(file.files);
			const cnt =  Array.from(file.files)
			return cnt;
		});	
	   }
	}
	
	fileMul.cnt();
	</script>
<?php
	for ($i=0; $i < count($file); $i++) {
	echo "이름: ".$file[$i]."<br>";
	echo "tmp : ".$file_tmp[$i]."<br>";
	echo "cnt : ".$file_cnt."<br>";
	}
?>
<body>
</html>

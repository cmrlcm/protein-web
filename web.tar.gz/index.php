<!DOCTYPE html>
<head>
	<style>
		header {
			border: 1px solid black;
			height:300px;
		}
		
		nav {
			border: 1px solid black;
			height:35px;
		}

		.main2 {
			border: 1px solid black;
			height: 1000px;
		}
		
		.main2 iframe {

		}

		.circle {
			display:block; 
			margin: auto; 
			height:75vh; 
		}

	</style>
	<script src="./bouncing_ball.js"></script>
</head>

<body>
<canvas id="canvas" class="circle">이 문장은 웹브라우저가 canvas요소를 지원하지 않을 때 나타납니다.</canvas>
<!--
	<header>
	</header>
	<nav>
		<p><a href="board.php" target="login.php"></a></p>
	</nav>
	<main>
		<iframe src="login.php" name="login">
		</iframe>
	</main>
-->
</body>
</html>

<!DOCTYPE html>
<html>
  <head>
	<meta charset='utf-8'>
	<style>		
	   table.table2 {
		border-collapse: separate;
		border-spacing: 1px;
		text-align: left;
		line-height: 1.5;
		border-top: 1px solid #ccc;
		margin: 20px 10px;
	   }
	
	   table.table2 tr {
		width: 50px;
		padding: 10px;
		font-weight: bold;
		vertical-align: top;
		border-bottom: 1px solid #ccc;
	   }
	
	   table.table2 td {
		width: 100px;
		padding: 10px;
		vertical-align: top;
		border-bottom: 1px solid #ccc;
	   }
	   input[type="submit"] {
		font-size:25px; text-align:center; color:white; margin-top:15px; margin-bottom:15px;
		background-color: #3c3c3c; font-weight: bold; font-family: "arial, courier new, times new roman, default";
		border-top: none; border-left: none; border-right: none; border-bottom: none;
		cursor: pointer;
    	   }
	
	   #title {
		outline-color: #3c3c3c;
		outline-style: solid;
		outline-width: 1px;
	   }

           #title:link {
		background-color: #3c3c3c;
	   }

	   #title:hover {
		outline-color: #3c3c3c;
		outline-style: solid;
		outline-width: 3px;
	   }

 	   .read_btn {
		width: 100px;
		height: 55px;
		text-align: center;
		margin: auto;
		margin-top: 20px;
	   }

	   .read_btn1 {
		height: 40px;
		width: 50px;
		font-size: 20px;
		text-align: center;
		background-color: white;
		border: 2px solid black;
		border-radius: 10px;
		cursor: pointer;
	   }

	   .read_btn1:hover {
		color: #5d5d5d;
	   }

	   div.finput {
		height: 49px;
		display: flex;
		align-items: center;
		justify-content: center;
		margin:-3px;
		
	   }

	   #file_input {
		display: none;
	   }

	   .file_list {
		width: 400px;
		height: 300px;
		text-align: center;
		margin: auto;
		font-size: 15px;
	   }

	   .file_remove {
		width: 22px;
		height: 22px;
		font-size: 12px;
		font-weight: bold;
		font-family: monospace;
		text-align: center;
		background-color: #dcdcdc;
		border-radius: 8px;
		border: 2px solid black;
		margin: auto;
		cursor: pointer;
	   }

	   .arr_remove {
		width: 22px;
		height: 22px;
		font-size: 12px;
		font-weight: bold;
		font-family: monospace;
		text-align: center;
		background-color: #dcdcdc;
		border-radius: 8px;
		border: 2px solid black;
		margin: auto;
		cursor: pointer;
	   }

	   p.margin {
		margin-top: 5px;
		margin-bottom: 2px;
	   }

	</style>		
  </head>
	
  <body>
	<?php
	   include './db/dbconnect.php';
	   $num = $_GET['num'];
	   session_start();

	   $_SESSION['num'] = $num;
	
	   // board 테이블
	   $query = "select title, content, date, id from board where number = $num";
	   $result = mysqli_query($connect, $query);
	   $rows = mysqli_fetch_assoc($result);
	   $user = $rows['id'];
	   $board = $rows['title'];
	   $content = $rows['content'];

	   // file 테이블
           $query = "select name, location from file where board_num = $num";
           $result = $connect->query($query);
           $count = mysqli_num_rows($result);
           $i = 0;
           while ( $rows = mysqli_fetch_assoc($result) ) {
                   $file_name[$i] = $rows['name'];
                   $i++;
           }
           unset($i);
	?>

	<form method="POST" name="writeBoard" action="./modify_action.php" enctype="multipart/form-data">
	   <table style="padding-top: 50px" align=center width=auto border=0 cellpadding=2>
	   <tr>
		<th id="title" style="background-color:#3c3c3c">
		     <input type="hidden" name="num" value="<?=$num ?>">	<!--  hidden으로 넘겨주는 이유는 input창없이 값을 넘기려고 쓰는 것. -->
		     <input type="submit" value="게시글 수정하기">		<!-- 후에, 사용자 계정을 만들게 되면, hidden을 사용해야할 것. -->
		</th>	
	   </tr>
	   <tr>
		<td bgcolor=white>
		    <table class="table2">
			<tr>
			     <td>작성자</td>
			     <td style="font-weight:550"><input type="hidden" name="user" value="<?=$user ?>"><?= $user ?></td>
			</tr>

			<tr>
			     <td>제목</td>
			     <td><input type=text name=title size=87 value="<?=$board ?>" required></td>
			</tr>

			<tr>
			     <td>내용</td>
			     <td>
				<textarea name=content cols=75 rows=15><?php echo $content; ?>
				</textarea>
		             </td>
			</tr>
			<?php for($i=0; $i < $count; $i++) { ?>
				<input type="hidden" class="file_exist" value="<?=$file_name[$i] ?>"></input> 
			<?php } ?>
		    </table>
		</td>
	   </tr>
	   </table>
		<input type="file" name="uploadFile[]" id="file_input" multiple>
		<table class="read_btn">
		<tr>
			<td class="read_btn1" style="padding: 0px">
			<label for="file_input" style="cursor:pointer">
			<div class="finput">첨부</div>
			</label>
			</td>
		</tr>
		</table>
		<div class="file_list" id="preview">
		</div>

		<script>
		history.replaceState({}, null, location.pathname);
		const fileList = new Array();
		const filesName = new Array();
		for (var k=0; k < document.getElementsByClassName("file_exist").length; k++) {
			fileList[k] = document.getElementsByClassName("file_exist")[k].value;
			filesName[k] = document.getElementsByClassName("file_exist")[k].value;
		}
	
		const filesArr = new Array();
		   const fileUploadCheck = {	
		     checkToDelete() {
		     	const uploadCheck = document.querySelector('#file_input');
		     	uploadCheck.addEventListener('change', function () {
				var fileName = Array();
				var fileLength = Array();
				var fileDot = Array();
				var fileNameType = Array();	
			  for (var j=0; j < uploadCheck.files.length; j++) {
				fileName.push(uploadCheck.files[j].name);
				fileLength.push(fileName[j].length);	
				fileDot.push(fileName[j].lastIndexOf("."));
				fileNameType[j] = fileName[j].substring(fileDot[j]+1, fileLength[j]).toLowerCase();
			  }
			
			var safeType = Array("hwp", "doc", "docx", "ppt", "pptx", "xls", "xlsx", "txt", "csv", "jpg", "jpeg", "gif", "png", "bmp", "pdf", "tar", "gz", "xz", "bz2");
		   	  for (var i=0; i < uploadCheck.files.length; i++) {
			    if (safeType.some( (type) => type === fileNameType[i]) ) {
	   			handler.init(uploadCheck.files[i]);

			        let reader = new FileReader();
				filesArr.push(uploadCheck.files[i]);
				filesName.push(fileName[i]);
				reader.readAsDataURL(uploadCheck.files[i]);

			    } else {
				alert("해당 확장자(." + fileNameType[i] + ")는 업로드가 불가능합니다.");
			    }
			  }
			const dataTransFer = new DataTransfer();
			   filesArr.forEach(file => {
			      dataTransFer.items.add(file);	
			   })

			document.querySelector('#file_input').files = dataTransFer.files;		
			console.dir(document.querySelector('#file_input').files);
 		     })
		  }
		}


	   const handler = {
		init(file) {
		  const fileInput = file;
		  const preview = document.querySelector('#preview');
		      if (fileInput.name) {
		       preview.innerHTML += `
		       <p id="${fileInput.lastModified}" class="margin" >
		 	 ${fileInput.name}
			 <button data-index='${fileInput.lastModified}' id='remove_file' class='file_remove'>X</button>
		       </p>`;
		      }
		},

		removeFile: () => {
		  document.addEventListener('click', function (e) {
			  if(e.target.className != 'file_remove') return;

				  const removeTargetId = e.target.dataset.index;
				  const removeTarget = document.getElementById(removeTargetId);
				  const files = document.querySelector('#file_input').files;
				  const dataTranster = new DataTransfer();

				  let index = filesArr.findIndex(k => k.lastModified == removeTargetId);
				  let indexName = filesArr.splice(index, 1);
				  let index2 = filesName.indexOf(indexName.name);
				  filesName.splice(index2, 1);

				  Array.from(files)
				      .filter(file => file.lastModified != removeTargetId)
				      .forEach(file => {
				      dataTranster.items.add(file);
				      })
				  removeTarget.remove(); 
				  document.querySelector('#file_input').files = dataTranster.files;
		  })
		},	

		initFile() {
		  const preview = document.querySelector('#preview');
		      if ( fileList ) {
			fileList.forEach( fileName => {
		          preview.innerHTML += `
		          <p id="${fileName}" class="margin">${fileName}
			  <button data-name='${fileName}' class='arr_remove'>X</button><input type="hidden" name="file_name[]" value="${fileName}"></p>`;
		        })
		      }
		},

		removeArr: () => {
		  document.addEventListener('click', function (e) {
			  if(e.target.className != 'arr_remove') return;
			  const removeNameId = e.target.dataset.name;
			  let index = fileList.indexOf(removeNameId);
			  let index2 = filesName.indexOf(removeNameId);
			  fileList.splice(index, 1);
			  filesName.splice(index2, 1);

			  const removeName = document.getElementById(removeNameId);
		  	  const preview = document.querySelector('#preview');
			  preview.removeChild(removeName);
		  })
		}
	   }
	   
           function notice() {
                if (confirm("동일한 이름의 파일이 존재합니다. 계속 진행하시겠습니까?")) {
                        return true;
                } else {
                        alert("취소하셨습니다.");
                        let frm = document.writeBoard;
                        frm.action ='<?=$_SERVER['PHP_SELF']?>';
                        frm.submit();
                }
           }

	   fileUploadCheck.checkToDelete();
	   handler.initFile();
	   handler.removeFile();
	   handler.removeArr();
	</script>
	</form>
  </body>
</html>

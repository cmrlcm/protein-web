<?php
header('Contet-type: application/json');
header('Access-Control-Allow-Origin: *');	// 이거 안하면 Access-Control-Allow-Origin에러 발생!
   $host = $_POST['host'];
   $user = $_POST['user'];
   $password = $_POST['password'];
   $dbname = $_POST['dbname'];

   $date = date('Y-m-d H:i:s');

if ($host) {
// Create connection
   $connect = mysqli_connect($host, $user, $password, $dbname);

      $query = "create table board (
	       number int not null auto_increment primary key,
	       title varchar(150) not null,
	       content text not null,
	       id varchar(20) not null,
	       date datetime not null,
	       hit int not null default 0);";

      $query .= "create table board_pw (
	       board_num int not null,
	       id varchar(20) not null,
	       password varchar(100) not null);";
	
      $query .= "create table member (
	       id varchar(20) not null,
	       password varchar(100) not null,
	       date datetime not null,
	       permit tinyint(3) unsigned);";   //권한

      $query .= "create table file (
	       file_num int not null auto_increment primary key,
	       board_num int not null,
	       name varchar(300) not null,
	       location varchar(500) not null,
	       user_id varchar(20) not null,
	       date datetime not null);";

      $query .= "insert into member (id, password, date, permit) values ('admin', '".md5(protein)."', '$date', 1);";

      // 멀티 쿼리 실행
      if (mysqli_multi_query($connect, $query)) {
	 do {
	    // 첫번째 결과 set 저장
	    if ($result = mysqli_store_result($connect)) {
	       // 행 하나 가져오기
	       while ($row = mysqli_fetch_row($result)) {
		     pirntf("%s\n", $row[0]);
	       }
	       // free 결과 set
	       mysqli_free_result($result);
	    }
	 } while (mysqli_more_results($connect) && mysqli_next_result($connect));
      }

// Check connection
   if ($connect == false) {
	$response = array(
	   'status' => 'error',
	   'message' =>  "Failure - DB_connect_error"
	);
   } else {
	// JSON 형식으로 응답 생성
 	$response = array(
	   'status' => 'success',
	   'message' => 'DB connect successful',
	   'host' => $host,
	   'user' => $user,
	   'password' => $password,
	   'dbname' => $dbname
	);
	
	$fp = fopen("./db/dbconnect.php", 'w');
   	fwrite($fp, "<?php \$connect = mysqli_connect('$host', '$user', '$password', '$dbname') or die(\"connect failed\"); ?>");
   	fclose($fp);
   }

   // JSON 데이터를 출력하고 스크립트 종료
   header('Content-type: application/json');
   echo json_encode($response);

   // 연결 종료
   mysqli_close($connect);
}

?>


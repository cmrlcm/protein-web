/*
// 동기식 전송인데 form에 type추가하기
        $('writeBoard').on('submit', e => {

                const uploadFile = document.querySelector('#file_input');
                const dataTransfer = new DataTransfer();


                filesArr.forEach(file => {dataTransfer.items.add(file); });
                uploadFile.files = dataTransfer.files;


                for(var j=0; j<uploadFile.files.length; j++) {
                        $('writeBoard').append($('<input/>', {type: 'file', name: 'uploadFile[]', value: uploadFile.files[j]}));
                }
                console.dir(uploadFile);

                $(this).submit();

                for(var i=0; i<uploadFile.files.length; i++) {
                        $(uploadFile.files[i]).remove();
                }
        });

////////////////////////////////////////////// 여기서부터 나뉨
// 비동기식 전송

        function formSubmit() {                                 // 비동기식 Ajax 방식 서버에서 처리해아할 것이 많다.
                 preventDefault();                              // 비동기식은 화면전환없이 정보처리할 때 사용.
                 const formData = new FormData([form]);
                 console.dir(form);

                for (var i = 0; i < filesArr.length; i++) {
                // formData.append('fileInput', blob, uploadCheck.files[i]);
                        formData.append('attach_file', filesArr[i]);
                }

                $.ajax({
                        url: './write_action.php',
                        type: "POST",
                        processData: false,
                        contentType: false,
                        data: fomrData
                })
                .done(function(data) {
                        console.log(data);
                })


/////////////////////////////////////////////////
                fetch('./write_action.php', {
                        metohd: 'POST',
                        headers: {
                                enctype: 'multipart/form-data'
                        },
                        body: formData
                })
        }
*/


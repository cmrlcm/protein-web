           function checkC() {
                document.addEventListener('submit', (e) => {
                        let fileNames = Array();
                        for (let i=0; i<filesArr.length; i++) {
                                fileNames = filesArr[i].name;
                        }
                        let arrCheck = compare(fileNames);
                        if (arrCheck) {
                                notice();
                        }
                })
           }

<script>
   $(document).ready( function() {
	$('#title_btn').on("click", (e) {
	   e.preventDefault();

	   let queryString = $("input[name=name]").val();
	   $.ajax({
		type: "POST",
		url: "./srcs/php/write_id_check.php",
		data: {name: queryString},
		async: false,
		datatype: "JSON",

		/* 응답 확인 */
		success: function(response) {
		  if (response.status == "exist") {
			alert(response.messsage);
			$("input[name=name]")[0].reset();
			return false;
		  }
		  if (response.status == "Non_exist") {
			return false;
		  }
		},

		/* 에러 확인 */
		error: function(xhr) {
			$("input[name=name]")[0].reset();
			return false;
		},

		/* 완료 확인 */
		complete: function(data, textStatus) {
			console.log(textStatus);
			return false;
		}
	   )};
	});
   });

</script>

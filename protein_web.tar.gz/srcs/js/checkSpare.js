function checkC(arr) {
        if ( arr ) {
                document.addEventListener('submit', (e) => {
                        notice()
                })
        }
}


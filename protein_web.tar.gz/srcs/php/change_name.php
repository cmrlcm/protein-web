<?php

function change_name($dir_path, $file_name) {
	$path = $dir_path;
	if ( !$path ) { return echo "error_no_path__change_name"; }
	if ( !$file_name ) { return echo "error_no_name__change_name"; }

	$is_file_exist = file_exists($path.$file_name);
	if ( !$is_file_exist ) { return $file_name; }

	$extention = strrchr($file_name, ".");
	$name = str_replace($extention, '', $file_name);
	$name_num = strrchr($name, "(");
	$original_name = str_replace($name_num, '', $name);
	$num = substr($name_num, -2, 1);

	if ( !$num ) { $file_num = 2; } 
	if ( $num ) { $file_num = (int) $num + 1; }	

	if ( $is_file_exist ) { 
	     $file_name = $original_name."(".$file_num.")".$extention;	
	     return change_name($number, $file_name);
	}
}
?>

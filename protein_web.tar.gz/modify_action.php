<?php
include './db/dbconnect.php';
include './srcs/php/change_name.php';

$num = $_POST['num'];
$title = $_POST['title'];
$content = $_POST['content'];

$file_list = $_POST["file_name"];		// 문자값으로 온 기존에 업로드된 파일

$upload = $_FILES["uploadFile"];		// 새로 업로드된 파일
$file_name = $upload['name'];

$date = date('Y-m-d H:i:s');

$query = "select * from board where number='$num'";
$result = $connect->query($query);
$rows = mysqli_fetch_assoc($result);
$id = $rows['id'];

// DB update
$query = "update board set title='$title', content='$content', date='$date' where number='$num'";
$result1 = $connect->query($query);

// DB에 있는 파일 체크
$query = "select name, location from file where board_num = $num";
$result2 = mysqli_query($connect, $query);
$cnt = mysqli_num_rows($result2);
  
$while ( $rows = mysqli_fetch_assoc($result2) ) {
	$file_loc[] = $rows['location'];
	$fname_inDB[] = $rows['name'];
}
$path = $file_loc[0];

// DB에서 파일 지우기
$filtered_array = array_filter($fname_inDB, function($file) use ($file_list) {			// DB파일명과 문자열에 있는 파일명 비교
    return !in_array($file, $file_list);
});

if ( !empty($filtered_array) ) {
	foreach($filtered_array as $file) {
		$query = "delete from file where board_num='$num' and name='$file'";
		$connect->query($query);
	}
	unset($file);
} 
unset($filtered_array);

// directory 생성
if ( !$path ) {
	$query = "select * from file order by file_num desc limit 1;";		// file 테이블 마지막행 출력 -> 필요없음. 까먹을까봐 넣음.
	$result3 = mysqli_query($connect, $query);
	$file_rows = mysqli_fetch_assoc($result3);
	$recent_loc = $file_rows['location'];
	list($dot, $root_dir, $sub_dir) = explode("/", $recent_loc);
	$sub_dir = intval($sub_dir) + 1;
	$target_dir = "./$root_dir/$sub_dir/";
	if ( $file_name[0] ) {
	   mkdir($target_dir, 0700, true);
	   $path = $target_dir;
	}
}

// 신규 파일 DB 저장
for ( $i = 0; $i < count($file_name); $i++ ) {
	$name = change_name($path, $file_name[$i]);
	$query = "insert into file (file_num, board_num, name, location, user_id, date) values (null, '$num', '$name', '$path', '$id', '$date');";
	mysqli_query($connect, $query);
}


/*	서버 파일 체크		*/
$dirHandle = opendir($path);
$file_array = array();

$j=0;
while ($file = readdir($dirHandle)) {
	if ($file == '.' || $file == '..') continue;
	if ( file_exists($path.$file) ) {
		$file_array[$j] = $file;		// 실제로 서버 안에 있는 파일들
		$j++;
	}
}
unset($j);
unset($file);
closedir($dirHandle);

$filtered_array = array_filter($file_array, function($file) use ($file_list) {			// 서버파일과 문자열에 있는 파일명 비교
    return !in_array($file, $file_list);
});

/*	서버 파일 지우기	*/
if ( !empty($filtered_array) ) {
	foreach($filtered_array as $file) {
		unlink($path.$file);
	}
	unset($file);
} 
unset($filtered_array);

/*	신규 파일 upload	*/
if ( $file_name[0] ) {
	for ($j=0; $j < count($file_name); $j++) {
		$error = $upload['error'][$j];
		$name = change_name($path, $file_name[$j]);
		$target_file = $path.basename($name);
		$target_tmp = $upload['tmp_name'][$j];
		move_uploaded_file( $target_tmp, $target_file );

		if ($error > 0 ) {
			error_log(print_r($upload), true);
			?> <script> alert("<?php echo "파일 업로드가 실패하였습니다." ?>"); </script>
		<?php
		}
	}
}

if ( empty($file_array) ) {
	$query = "delete from file where board_num='$num'";
	$connect->query($query);
}
unset($file_name);
unset($file_array);
?>

<script>
	alert("수정되었습니다.");
	location.replace("./read.php?num=<?=$num ?>");
</script>
